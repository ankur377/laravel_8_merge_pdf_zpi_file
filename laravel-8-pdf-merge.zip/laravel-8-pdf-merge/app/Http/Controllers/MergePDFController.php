<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use setasign\Fpdi\Fpdi;
 
class MergePDFController extends Controller
{
    public function process(Request $request) {
        $file=Storage::disk('local')->put('invoice(1).pdf',file_get_contents(public_path('invoice(1).pdf')));
        $file=Storage::disk('local')->put('invoice(3).pdf',file_get_contents(public_path('invoice(4).pdf')));
        $files = [Storage::disk('local')->path("invoice(1).pdf"), Storage::disk('local')->path('invoice(3).pdf')];
        $this->merge($files,Storage::disk('local')->path('newtest.pdf'));
        return response()->file(Storage::disk('local')->path('newtest.pdf'));
 
    }
 
    public function merge($files, $outputPath)
    {
        $fpdi = new FPDI;
        foreach ($files as $file) {
            $filename  = $file;
            $count = $fpdi->setSourceFile($filename);
            for ($i=1; $i<=$count; $i++) {
                $template   = $fpdi->importPage($i);
                $size       = $fpdi->getTemplateSize($template);
                $fpdi->AddPage($size['orientation'], array($size['width'], $size['height']));
                $fpdi->useTemplate($template);
            }
 
        }
        $fpdi->Output($outputPath, 'F');
    }
}
 